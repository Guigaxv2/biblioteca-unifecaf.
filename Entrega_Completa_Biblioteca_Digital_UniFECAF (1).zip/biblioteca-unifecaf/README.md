# Biblioteca Digital UniFECAF

Projeto acadêmico demonstrativo desenvolvido exclusivamente com **HTML5 e CSS3**, sem JavaScript e sem bibliotecas externas.

## Como executar
1. Abra `index.html` em qualquer navegador atualizado.
2. Navegue pelo menu para visualizar as seções Sobre, Livros, Unidades e Contato.
3. Para testar o celular, reduza a janela do navegador ou use as ferramentas de desenvolvedor (F12 > modo responsivo).

## Estrutura
- `index.html`: estrutura e conteúdo semântico.
- `css/style.css`: identidade visual, grids e media queries.
- `assets/imagens/`: ilustrações SVG locais e acessíveis.

## Observações importantes
Os títulos dos livros e as informações sobre espaços são **ilustrativos** e não representam dados oficiais sobre o acervo ou endereços reais. O botão externo direciona ao site oficial da instituição. A página é um protótipo visual, **não inclui login, buscas reais, empréstimos ou banco de dados**.

## Publicação
Configure GitHub Pages para hospedar a branch `main` na pasta `/ (root)`. Instruções completas no arquivo `GUIA_DE_ENTREGA.txt` da pasta superior.
